export interface LoginAdmin {
    librarianUsername:string;
    librarianPassword:string;
}
