export interface Loginadminresponse {
    librarianUsername:string;
}
