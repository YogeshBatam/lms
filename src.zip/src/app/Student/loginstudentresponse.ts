export interface Loginstudentresponse {
    userName:string;
}
