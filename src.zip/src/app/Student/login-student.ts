export interface LoginStudent {
    userName:string;
    password:string;
}
