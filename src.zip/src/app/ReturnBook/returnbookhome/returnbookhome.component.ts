import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-returnbookhome',
  templateUrl: './returnbookhome.component.html',
  styleUrls: ['./returnbookhome.component.css']
})
export class ReturnbookhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
