import { ReturnBook } from "./returnbook";

describe('Returnbook', () => {
  it('should create an instance', () => {
    expect(new ReturnBook()).toBeTruthy();
  });
});
