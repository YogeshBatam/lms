import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fine-home',
  templateUrl: './fine-home.component.html',
  styleUrls: ['./fine-home.component.css']
})
export class FineHomeComponent implements OnInit {
  title = 'fine1';

  constructor() { }

  ngOnInit(): void {
  }

}
