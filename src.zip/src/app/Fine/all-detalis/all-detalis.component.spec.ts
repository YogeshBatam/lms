// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { AllDetalisComponent } from './all-detalis.component';

// describe('AllDetalisComponent', () => {
//   let component: AllDetalisComponent;
//   let fixture: ComponentFixture<AllDetalisComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ AllDetalisComponent ]
//     })
//     .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AllDetalisComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
