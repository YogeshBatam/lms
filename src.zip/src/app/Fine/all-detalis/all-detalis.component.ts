// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-all-detalis',
//   templateUrl: './all-detalis.component.html',
//   styleUrls: ['./all-detalis.component.css']
// })
// export class AllDetalisComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }
