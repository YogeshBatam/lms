import { Fine } from './fine';

describe('Fine', () => {
  it('should create an instance', () => {
    expect(new Fine()).toBeTruthy();
  });
});
