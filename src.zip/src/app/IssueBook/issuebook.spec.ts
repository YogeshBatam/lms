import { Issuebook } from './issuebook';

describe('Issuebook', () => {
  it('should create an instance', () => {
    expect(new Issuebook(0,0,0,'','','',0));
  });
});
