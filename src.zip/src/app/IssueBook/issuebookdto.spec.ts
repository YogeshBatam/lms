import { Issuebookdto } from './issuebookdto';

describe('Issuebookdto', () => {
  it('should create an instance', () => {
    expect(new Issuebookdto()).toBeTruthy();
  });
});
